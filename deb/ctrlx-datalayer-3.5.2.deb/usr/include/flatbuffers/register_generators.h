#pragma once
#include "flatc.h"

namespace flatbuffers {

class RegisterGenerators
{
public:
  static void registerAllGeneartors(FlatCompiler &compiler);

 protected:
 private:
};

}
