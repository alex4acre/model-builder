#pragma once
#include "datalayer.h"
#include "metadata_generated.h"
#include "metadata_helper.h"
#include "comm/datalayer/program_task_generated.h"
#include "comm/datalayer/program_task_all_generated.h"
#include "comm/datalayer/address2.h"
#include <random>
#include <map>
#include <chrono>
#include <mutex>

#ifdef __linux__
#include <pthread.h>
#endif

namespace comm {
namespace datalayer {
DATALAYER_VERSION_NAMESPACE

class Task
{
public:
  Task(const std::string& id, const Variant* parameters)
    : m_id(id)
    , m_parameters(*parameters)
    , m_taskState(ProgramTaskState_pending)
  {
    m_createdAt = getTimestamp();
    setState(ProgramTaskState_pending, 0);
  }

  virtual ~Task() = default;

  void setState(comm::datalayer::ProgramTaskState state, uint32_t progress, const std::string& progressInfo = "")
  {
    if ((state == ProgramTaskState::ProgramTaskState_done ||
         state == ProgramTaskState::ProgramTaskState_failed) &&
        !m_finishedAt) {
      m_finishedAt = getTimestamp();
    }
    flatbuffers::FlatBufferBuilder builder;
    auto id = builder.CreateString(m_id);
    auto info = builder.CreateString(progressInfo);
    builder.Finish(comm::datalayer::CreateProgramTask(builder, id, state, progress, 0, info, 0, m_createdAt, m_finishedAt));
    m_state.copyFlatbuffers(builder);
    m_taskState = state;
  }

  void setState(const Variant &state)
  {
    if (STATUS_FAILED(state.verifyFlatbuffers(VerifyProgramTaskBuffer)))
    {
      return;
    }
    auto myState = UnPackProgramTask(state.getData());
    myState->id = m_id;
    flatbuffers::FlatBufferBuilder builder;
    builder.Finish(ProgramTask::Pack(builder, myState.get()));
    m_state.copyFlatbuffers(builder);
    m_taskState = myState->state;
  }

  void setError(uint32_t mainDiagnosisCode, uint32_t detailedDiagnosisCode, const std::string& dynamicDescription = "")
  {
    if (!m_finishedAt) {
      m_finishedAt = getTimestamp();
    }
    auto task = UnPackProgramTask(m_state.getData());
    flatbuffers::FlatBufferBuilder builder;
    auto diagnosis = CreateDiagnosisDirect(builder, mainDiagnosisCode, detailedDiagnosisCode, dynamicDescription.c_str(), "datalayer");
    builder.Finish(CreateProgramTaskDirect(builder, task->id.c_str(), ProgramTaskState_failed, 100, diagnosis, nullptr, nullptr, m_createdAt, m_finishedAt));
    m_state.copyFlatbuffers(builder);
    m_taskState = ProgramTaskState_failed;
  }

  void setError(const Variant &diagnosis)
  {
    if (STATUS_FAILED(diagnosis.verifyFlatbuffers(VerifyDiagnosisBuffer)))
    {
      return;
    }
    auto task = UnPackProgramTask(m_state.getData());
    auto diag = UnPackDiagnosis(diagnosis.getData());
    flatbuffers::FlatBufferBuilder builder;
    auto diagOffset = Diagnosis::Pack(builder, diag.get());
    builder.Finish(CreateProgramTaskDirect(builder, task->id.c_str(), ProgramTaskState_failed, 100, diagOffset, nullptr, nullptr, m_createdAt, m_finishedAt));
    m_state.copyFlatbuffers(builder);
    m_taskState = ProgramTaskState_failed;
  }

  virtual comm::datalayer::MetadataT onMetadata()
  {
    comm::datalayer::MetadataT metadata;
    metadata.nodeClass = NodeClass_Resource;
    comm::datalayer::AllowedOperationsT allowedOperations;
    allowedOperations.read = true;
    allowedOperations.write = false;
    allowedOperations.create = false;
    allowedOperations.delete_ = true;
    allowedOperations.browse = true;
    metadata.operations = std::make_unique<comm::datalayer::AllowedOperationsT>(allowedOperations);
    metadata.description = "Information about task properties (node name, task state, task progress).";
    comm::datalayer::ReferenceT ref;
    ref.type = "readType";
    ref.targetAddress = "types/datalayer/program-task";
    metadata.references.push_back(std::make_unique<comm::datalayer::ReferenceT>(ref));
    return metadata;
  }

  virtual Variant getState() final
  {
    return m_state;
  };

  virtual ProgramTaskState getTaskState() final
  {
    return m_taskState;
  }

  virtual Variant getParameters() final
  {
    return m_parameters;
  }

  virtual std::string getResultNodeName()
  {
    return m_resultNodeName;
  }

  virtual Variant getResult()
  {
    return Variant();
  }

  virtual Variant getResultMetadata()
  {
    Variant metadata;
    MetadataHelper::createMetadata(metadata, NodeClass_Variable, true, false, false, false, false, {}, "Result of the task.");
    return metadata;
  }

  uint64_t getTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto durationSinceEpoch = now.time_since_epoch();
    auto durationSince1601 = durationSinceEpoch + std::chrono::seconds(11644473600); // seconds from 1601 bis 1970
    uint64_t time = std::chrono::duration_cast<std::chrono::microseconds>(durationSince1601).count() * 10;
    return time;
  }

protected:
  const std::string m_id;
  Variant m_parameters;
  std::string m_resultNodeName = "";

private:

  ProgramTaskState m_taskState;
  Variant m_state;
  uint64_t m_createdAt = 0;
  uint64_t m_finishedAt = 0;

};

class Program : IProviderNode
{
public:
  Program(IProvider* provider, const std::string& baseAddress, const std::string& pathParameterType = "")
    : m_provider(provider)
    , m_pathParameterType(pathParameterType)
    , m_pathType(pathParameterType)
    , m_baseAddress(baseAddress)
  {
    m_provider->registerNode(m_baseAddress, this);
    m_provider->registerNode(m_baseAddress + "/*", this);
    m_provider->registerNode(m_baseAddress + "/*/parameters", this);
    if (m_pathParameterType.rfind(".bfbs") != std::string::npos) {
      m_pathType = "types/program/" + m_baseAddress;
      m_provider->registerType("types/program/" + m_baseAddress, pathParameterType);
    }
  };

  virtual ~Program()
  {
    garbageCollection();
    m_provider->unregisterNode(m_baseAddress);
    m_provider->unregisterNode(m_baseAddress + "/*");
    m_provider->unregisterNode(m_baseAddress + "/*/parameters");
    if (m_pathParameterType.rfind(".bfbs") != std::string::npos)
    {
      m_provider->unregisterType("types/program/" + m_baseAddress);
    }
  };

  void setBaseAddressDescription(const std::string& desciprion)
  {
    m_descriptionBaseAddress = desciprion;
  }

  /************************************************************************/
  /* methods to override                                                  */
  /************************************************************************/
  virtual DlResult onCreate(const std::string& id, const Variant* parameters, Task** task) = 0;

  virtual DlResult onRemove(const std::string&)
  {
    return DlResult::DL_OK;
  }

  // Is called before execution of onBrowse(), can e.g. be used for the garbage collection, so that the sub nodes are up-to-date when browsing
  virtual DlResult preOnBrowse()
  {
    return DlResult::DL_OK;
  }

  virtual DlResult garbageCollection()
  {
    std::lock_guard<InheritRecursiveMutex> guard(m_mapMtx);
    for (auto task = m_mapTasks.begin(); task != m_mapTasks.end();)
    {
      auto state = task->second->getTaskState();
      if ((state == ProgramTaskState_done) ||
          (state == ProgramTaskState_failed))
      {
        delete task->second;
        task = m_mapTasks.erase(task);
      }
      else
      {
        task++;
      }
    }
    return DlResult::DL_OK;
  }

  /************************************************************************/
  /* IProviderNode interface                                              */
  /************************************************************************/
  void onCreate(const std::string& address, const comm::datalayer::Variant* parameters, const comm::datalayer::IProviderNode::ResponseCallback& callback) override
  {
    std::lock_guard<InheritRecursiveMutex> guard(m_mapMtx);
    if (address != m_baseAddress)
    {
      callback(DlResult::DL_UNSUPPORTED, nullptr);
      return;
    }
    if (!m_pathType.empty() && (parameters == nullptr))
    {
      callback(DlResult::DL_TYPE_MISMATCH, nullptr);
      return;
    }
    std::string myID;
    for (;;) // LCOV_EXCL_LINE
    {
      myID = getUuid();
      if (m_mapTasks.find(myID) == m_mapTasks.end())
      {
        break;
      }
    }

    Task* task;
    DlResult result;
    if (nullptr == parameters)
    {
      comm::datalayer::Variant emptyData;
      emptyData.setValue("");
      result = onCreate(myID, &emptyData, &task);
    }
    else
    {
      result = onCreate(myID, parameters, &task);
    }

    if (STATUS_FAILED(result))
    {
      callback(result, parameters);
      return;
    }

    m_mapTasks[myID] = task;
    Variant createdResource;
    createdResource.setValue(m_baseAddress + "/" + myID);
    if (task->getResultNodeName().length())
    {
      m_provider->registerNode(m_baseAddress + "/" + myID + "/" + task->getResultNodeName(), this);
    }
    callback(DlResult::DL_OK_NO_CONTENT, &createdResource);
  };

  void onRemove(const std::string& address, const ResponseCallback& callback) override
  {
    std::string part = address.substr(m_baseAddress.size());
    if (part.length())
    {
      Address2 addr(part);
      auto parts = addr.parse();
      if (parts.size() == 1)
      {
        std::lock_guard<InheritRecursiveMutex> guard(m_mapMtx);

        auto myID = address.substr(m_baseAddress.size() + 1);
        auto task = m_mapTasks.find(myID);
        if (task == m_mapTasks.end())
        {
          callback(DlResult::DL_INVALID_ADDRESS, nullptr);
          return;
        }
        auto state = task->second->getTaskState();
        if ((state != ProgramTaskState_done) &&
            (state != ProgramTaskState_failed))
        {
          callback(DlResult::DL_INVALID_OPERATION_MODE, nullptr);
          return;
        }

        auto result = onRemove(myID);
        m_provider->unregisterNode(m_baseAddress + "/" + task->first + "/" + task->second->getResultNodeName());

        delete task->second;
        m_mapTasks.erase(task);
        callback(result, nullptr);
        return;
      }
    }

    callback(DlResult::DL_UNSUPPORTED, nullptr);
    return;
  };

  void onBrowse(const std::string& address, const ResponseCallback& callback) override
  {
    DlResult dlResult = preOnBrowse();

    std::lock_guard<InheritRecursiveMutex> guard(m_mapMtx);
    if (address == m_baseAddress)
    {
      std::vector<std::string> result;
      result.reserve(m_mapTasks.size());
      for (auto item : m_mapTasks)
      {
        result.push_back(item.first);
      }
      Variant returnValue;
      returnValue.setValue(result);
      callback(dlResult, &returnValue);
      return;
    }
    callback(DlResult::DL_UNSUPPORTED, nullptr);
  };

  void onRead(const std::string& address, const comm::datalayer::Variant* , const ResponseCallback& callback) override
  {
    std::lock_guard<InheritRecursiveMutex> guard(m_mapMtx);
    std::string part = address.substr(m_baseAddress.size());
    if (part.length())
    {
      Address2 addr(part);
      auto parts = addr.parse();
      // return state of one task
      auto task = m_mapTasks.find(parts[0]);
      if (task == m_mapTasks.end())
      {
        callback(DlResult::DL_INVALID_ADDRESS, nullptr);
        return;
      }
      if (parts.size() == 1)
      {
        auto state = task->second->getState();
        callback(DlResult::DL_OK, &state);
        return;
      }
      if (parts.size() == 2)
      {
        if (parts[1] == "parameters")
        {
          auto parameters = task->second->getParameters();
          callback(DlResult::DL_OK, &parameters);
          return;
        }
        if (parts[1] == task->second->getResultNodeName())
        {
          auto result = task->second->getResult();
          callback(DlResult::DL_OK, &result);
          return;
        }
      }
      callback(DlResult::DL_INVALID_ADDRESS, nullptr);
    }
    else
    {
      flatbuffers::FlatBufferBuilder builder;
      std::vector<flatbuffers::Offset<ProgramTask>> tasks;
      // return state of all tasks
      for (auto& task : m_mapTasks)
      {
        auto state = task.second->getState();
        auto progTask = UnPackProgramTask(state.getData());
        tasks.push_back(CreateProgramTask(builder, progTask.get()));
      }
      builder.Finish(CreateProgramTaskAllDirect(builder, &tasks));
      Variant states;
      states.copyFlatbuffers(builder);
      callback(DlResult::DL_OK, &states);
    }
  };

  void onWrite(const std::string& , const Variant* , const ResponseCallback& callback) override
  {
    callback(DlResult::DL_UNSUPPORTED, nullptr);
  };

  void onMetadata(const std::string& address, const ResponseCallback& callback) override
  {
    Variant metadata;
    std::string part = address.substr(m_baseAddress.size());
    if (part.length())
    {
      Address2 addr(part);
      auto parts = addr.parse();

      auto task = m_mapTasks.find(parts[0]);
      if (task == m_mapTasks.end())
      {
        callback(DlResult::DL_INVALID_ADDRESS, nullptr);
        return;
      }

      if (parts.size() == 1)
      { // metadata of task
        flatbuffers::FlatBufferBuilder builder;
        MetadataT customMetadata = task->second->onMetadata();

        builder.Finish(comm::datalayer::Metadata::Pack(builder, &customMetadata));
        metadata.copyFlatbuffers(builder);
        callback(DlResult::DL_OK, &metadata);
        return;
      }
      if (parts.size() == 2)
      { // subnode of task
        if (parts[1] == "parameters")
        {
          if (m_pathType.empty())
          {
            MetadataHelper::createMetadata(metadata, NodeClass_Variable, true, false, false, false, false, {}, "Properties of the task (empty).");
          }
          else
          {
            MetadataHelper::createMetadata(metadata, NodeClass_Variable, true, false, false, false, false, {{"readType", m_pathType}}, "Properties of the task.");
          }

          callback(DlResult::DL_OK, &metadata);
          return;
        }
        if (parts[1] == task->second->getResultNodeName())
        {
          auto result = task->second->getResultMetadata();
          callback(DlResult::DL_OK, &result);
          return;
        }
      }
    }
    else
    {
      if (m_pathType.empty())
      {
        MetadataHelper::createMetadata(metadata, NodeClass_Program, true, false, true, false, true, {{"readType", "types/datalayer/program-task-all"}}, m_descriptionBaseAddress);
      }
      else
      {
        MetadataHelper::createMetadata(metadata, NodeClass_Program, true, false, true, false, true, {
          {"readType", "types/datalayer/program-task-all"},
          {"createType", m_pathType}},
          m_descriptionBaseAddress);
      }

      callback(DlResult::DL_OK, &metadata);
      return;
    }
    callback(DlResult::DL_INVALID_ADDRESS, nullptr);
  };

private:


protected:
  class InheritRecursiveMutex : public std::recursive_mutex {
  public:
    InheritRecursiveMutex() {
#ifdef __linux__
      // Destroy the underlying mutex
      ::pthread_mutex_destroy(native_handle());

      // Create mutex attribute with desired protocol and type
      ::pthread_mutexattr_t attr;
      ::pthread_mutexattr_init(&attr);
      ::pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
      ::pthread_mutexattr_setprotocol(&attr, PTHREAD_PRIO_INHERIT);
      // Initialize the underlying mutex
      ::pthread_mutex_init(native_handle(), &attr);
      // The attribute shouldn't be needed any more
      ::pthread_mutexattr_destroy(&attr);
#endif
    };

    virtual ~InheritRecursiveMutex() {
    };

  protected:
  private:
  };

  virtual std::string getUuid() {
    // Generate a timestamp in the format YYYY.MM.DD-HH:MM:SS
    std::string timestamp;
    std::time_t t = std::time(nullptr);
    std::tm* tmPtr;
#ifdef __linux__
    tmPtr = std::localtime(&t);
#else
    std::tm tm; // LCOV_EXCL_START
    if (0 == localtime_s(&tm, &t))
    {
      tmPtr = &tm;
    } // LCOV_EXCL_STOP
#endif

    if (tmPtr == nullptr) { timestamp = "NoTime"; }
    else {
      std::ostringstream oss;
      oss << std::put_time(tmPtr, "%FT%H-%M-%S");
      timestamp = oss.str();
    }

    // Generate 8 random letters
    static std::random_device dev;
    static std::mt19937 rng(dev());
    const char* v = "abcdefghijklmnopqrstuvwxyz";
    std::uniform_int_distribution<int> dist(0, static_cast<int>(strlen(v) - 1));
    std::string randomLetters;
    for (int i = 0; i < 8; i++) {
      randomLetters += v[dist(rng)];
    }

    // Combine timestamp and random letters and return a string
    return timestamp + "-" + randomLetters;
  }

  std::string m_descriptionBaseAddress = "";
  InheritRecursiveMutex m_mapMtx;
  typedef std::map<std::string, Task*> TMapTasks;
  TMapTasks m_mapTasks;
  IProvider* m_provider;
  std::string m_pathParameterType;
  std::string m_pathType;
  std::string m_baseAddress;
};

}
}
}

