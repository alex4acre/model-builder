#pragma once

#include "datalayer_defs.h"
#include <string>
#include <vector>

namespace comm {
namespace datalayer {
DATALAYER_VERSION_NAMESPACE

class Address2 {
private:
  std::string m_token = "/";
  std::string m_path;
  std::vector<std::string> m_elements;
  std::vector<std::string> m_elementsUnescaped;

public:
  //
  // static helper to unescape characters
  //
  static std::string unescape(const std::string& str) {
    std::string result;
    bool escape = false;

    for (char c : str) {
      if (escape) {
        result += c;
        escape = false;
      } else if (c == '\\') {
        escape = true;
      } else {
        result += c;
      }
    }

    return result;
  }

  //
  // helper to escape characters
  //
  static std::string escape(const std::string& str) {
    std::string result;

    for (char ch : str) {
      if (ch == '/' || ch == '\\' || ch == '*') {
        result += '\\';
      }

      result += ch;
    }

    return result;
  }

private:
  //
  // enumeration of strings
  //
  void append(void) {
    generate(m_elements);
  }

  template<typename T, typename... Args>
  void append(T&& obj, Args&&... args) {
    // create temporary vector
    m_elements.push_back(obj);
    append(args...);
  }

  //
  // generate (address elements -> address path)
  //
  void generate(const std::vector<std::string> elements) {
    m_elements.clear();
    m_elementsUnescaped.clear();
    m_path.clear();

    for (const auto& it : elements) {
      // append the escaped element to the complete path
      m_path.append(it).append(m_token);

      // store the original element to vector of strings
      m_elements.push_back(it);
      m_elementsUnescaped.push_back(unescape(it));
    }
  }

  //
  // parse (address path -> address elements)
  //
  void parse(const std::string& in) {
    // check if the input string starts with the token and remove the leading token if present
    std::string address(0 == in.find(m_token, 0) ? in.substr(m_token.length()) : in);

    // clear the current elements and path
    m_elements.clear();
    m_elementsUnescaped.clear();
    m_path.clear();

    std::string element;
    bool escaped = false;

    // iterate through each character in the address string
    for (size_t i = 0; i < address.size(); ++i) {
      char c = address[i];
      if (escaped) {
        // if the previous character was an escape character, add the current character to the element
        element += c;
        escaped = false;
      } else if (c == '\\') {
        // if the current character is an escape character, set the escape flag
        element += c;
        escaped = true;
      } else if (c == m_token[0] && !escaped) {
        // if the current character is the token and not escaped, add the current element to the elements vector
        m_elements.push_back(element);
        m_elementsUnescaped.push_back(unescape(element));
        element.clear();
      } else {
        // otherwise, add the current character to the element
        element += c;
      }
    }

    // add the last element to the elements vector if it's not empty
    if (!element.empty()) {
      m_elements.push_back(element);
      m_elementsUnescaped.push_back(unescape(element));
    }

    // concatenate the elements to form the complete path
    for (const auto& it : m_elements) {
      m_path.append(it).append(m_token);
    }
  }

public:
  //
  // parse constructors (address path -> address elements), always use paths with escaped characters (e.g. "test/node\\/with\\*escaped\\\\characters/end")
  //
  Address2(const std::string& path) {
    parse(path);
  }

  Address2(const char token, const std::string& path): m_token(std::string(1, token)) {
    parse(path);
  }

  //
  // generate constructors (address elements -> address path), choose whether use escaped or unescaped characters
  //
  Address2(const std::vector<std::string>& elements, bool escaped = true) {
    if (escaped)
    {
      generate(elements);
    }
    else
    {
      std::vector<std::string> escapedElements;
      for (const auto& element : elements)
      {
        escapedElements.push_back(escape(element));
      }
      generate(escapedElements);
    }
  }

  // Caution: This constructor can only be used with escaped address element!
  template<class... Args> Address2(const std::string& element, Args&&... args) {
    append(element, std::forward<Args>(args)...);
  }

  Address2(char token, const std::vector<std::string>& elements, bool escaped = true): m_token(std::string(1, token)) {
    if (escaped)
    {
      generate(elements);
    }
    else
    {
      std::vector<std::string> escapedElements;
      for (const auto& element : elements)
      {
        escapedElements.push_back(escape(element));
      }
      generate(escapedElements);
    }
  }

  // Caution: This constructor can only be used with escaped address element!
  template<class... Args> Address2(char token, const std::string& element, Args&&... args) : m_token(std::string(1, token)) {
    append(element, std::forward<Args>(args)...);
  }

  //
  // default constructors
  //
  Address2() = delete;
  ~Address2() = default;

  //
  // additional token getter / setter
  //
  const std::string token(void) {
    return m_token;
  }
  void token(const std::string& in) {
    ("\\" != m_token) ? m_token = in : m_token = m_token; std::vector<std::string> elements(m_elements); generate(elements);
  }
  void token(const char& in) {
    token(std::string(1, in));
  }

  //
  // operators
  //
  Address2& operator=(const std::string& path) {
    parse(path);
    return *this;
  }

  // use only for escaped vector elements
  Address2& operator=(const std::vector<std::string>& elements) {
    generate(elements);
    return *this;
  }

  // use for unescaped vector elements instead of operator=
  Address2& assign(const std::vector<std::string>& elements, bool escaped = true) {
    if (escaped) {
      generate(elements);
    } else {
      std::vector<std::string> escapedElements;
      for (const auto& element : elements) {
        escapedElements.push_back(escape(element));
      }
      generate(escapedElements);
    }
    return *this;
  }

  bool operator==(const Address2& var2) const {
    return (0 == m_path.compare(var2.generate()));
  }

  bool operator!=(const Address2& var2) const {
    return (0 != m_path.compare(var2.generate()));
  }

  operator std::string() const {
    return m_path;
  }

  // use only for escaped vector elements
  operator std::vector<std::string>() const {
    return m_elements;
  }

  //
  // getter address path
  //
  const std::string& generate() const {
    return m_path;
  }

  //
  // getter address elements
  //
  const std::vector<std::string>& parse(bool escaped = true) const {
    if (escaped) {
      return m_elements;
    }
    else {
      return m_elementsUnescaped;
    }
  }
};
}
}
}
