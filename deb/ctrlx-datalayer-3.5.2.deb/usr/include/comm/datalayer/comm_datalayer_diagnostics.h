#pragma once

//! @copyright (C) 2021-20xx Bosch Rexroth AG
//!
//! The reproduction, distribution and utilization of this file as well as the communication of its contents to others
//! without express authorization is prohibited. Offenders will be held liable for the payment of damages.
//! All rights reserved in the event of the grant of a patent, utility model or design.

//! @file comm_datalayer_diagnostics.h
//! @brief This header contains the diagnostics declarations of component 'comm.datalayer'

// File format version: 1.0.1

#include <cstdint>

namespace comm
{
  namespace datalayer
  {
    constexpr char LIBRARY_DIAGNOSTICS_FILE_NAME[] = "comm_datalayer_diagnostics_en-US.json";  //!< File name with diagnostics used in this library.

    // --------------------
    // Main diagnostics
    // --------------------
    constexpr std::uint32_t MAIN_DIAG_080E0280 = 0x080E0280;  //!< Data layer provider connection interrupted
    constexpr std::uint32_t MAIN_DIAG_080E0281 = 0x080E0281;  //!< Data layer remote connection interrupted
    constexpr std::uint32_t MAIN_DIAG_080F8280 = 0x080F8280;  //!< NVRam not available

    // --------------------
    // Detailed diagnostics
    // --------------------
    constexpr std::uint32_t DETAILED_DIAG_0C340000 = 0x0C340000;  //!< The Data Layer provider was logged off due to inactivity.
    constexpr std::uint32_t DETAILED_DIAG_0C340004 = 0x0C340004;  //!< Failed to initialize hardware NVRam
    constexpr std::uint32_t DETAILED_DIAG_0C340005 = 0x0C340005;  //!< Data layer remote connection could not be established
  }
}
